### Snippet name

Brief description

#### HTML

```html

```

#### CSS

```css
```

#### Demo

<!-- Leave this blank, the build script will generate the demo for you. -->

#### Explanation

<!-- Use a step-by-step (ordered) list if possible. Keep it concise. -->

#### Browser support

<!-- Use the checkmark or the warning emoji, see the existing snippets. -->

<span class="snippet__support-note">⚠️ Caveat?</span>

<!-- Whenever possible, link a `caniuse` feature which allows the browser support percentage to be displayed. -->

- https://caniuse.com/#feat=some-feature

<!-- tags: (separate each by a comma) -->
