# 30 Seconds of CSS

<a href="https://30-seconds.github.io/30-seconds-of-css/" target="_blank">![logo](https://i.imgur.com/kPMfyD4.jpg)</a>

[![License](https://img.shields.io/badge/license-CC0--1.0-blue.svg)](https://github.com/30-seconds/30-seconds-of-css/blob/master/LICENSE) [![Gitter chat](https://img.shields.io/badge/chat-on%20gitter-4FB999.svg)](https://gitter.im/30-seconds-of-css/Lobby) [![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](http://makeapullrequest.com) [![Insight.io](https://img.shields.io/badge/insight.io-Ready-brightgreen.svg)](https://insight.io/github.com/30-seconds/30-seconds-of-css/tree/master/?source=0)

A curated collection of useful CSS snippets you can understand in 30 seconds or less.
Inspired by [30 seconds of code](https://github.com/Chalarangelo/30-seconds-of-code).

## View online

https://30-seconds.github.io/30-seconds-of-css/

## Contributing

See CONTRIBUTING.md for the snippet template.

#### Related projects

- [30 Seconds of Code](https://30secondsofcode.org/)
- [30 Seconds of Interviews](https://30secondsofinterviews.org/)
- [30 Seconds of React](https://github.com/30-seconds/30-seconds-of-react)
